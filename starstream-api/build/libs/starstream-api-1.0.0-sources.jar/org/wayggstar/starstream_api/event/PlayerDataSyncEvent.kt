package org.wayggstar.starstream_api.event

import org.wayggstar.starstream_api.data.IPlayerData

/**
 * 순수 데이터 이벤트 클래스.
 * core 모듈이 NeoForge EventBus에 publish한다.
 * ui 모듈은 core의 EventBus 리스너를 통해 받는다.
 */
data class PlayerDataSyncEvent(
    val playerData: IPlayerData,
    val isFullSync: Boolean = false
)
