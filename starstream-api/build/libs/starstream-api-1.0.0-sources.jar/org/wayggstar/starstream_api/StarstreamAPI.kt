package org.wayggstar.starstream_api

import org.wayggstar.starstream_api.data.IPlayerData
import org.wayggstar.starstream_api.data.ISkill
import org.wayggstar.starstream_api.data.IStory
import org.wayggstar.starstream_api.data.ITrait
import org.wayggstar.starstream_api.data.IWarp

/**
 * Starstream API 엔트리포인트.
 *
 * core 모드가 구현체를 등록하고, ui 모드가 이를 조회하여 사용한다.
 * 순수 Kotlin 라이브러리 — NeoForge 의존성 없음.
 */
object StarstreamAPI {

    private val _registeredTraits = mutableMapOf<String, ITrait>()
    private val _registeredSkills = mutableMapOf<String, ISkill>()
    private val _registeredStories = mutableMapOf<String, IStory>()
    private val _registeredWarps = mutableMapOf<String, IWarp>()

    val registeredTraits: Map<String, ITrait> get() = _registeredTraits.toMap()
    val registeredSkills: Map<String, ISkill> get() = _registeredSkills.toMap()
    val registeredStories: Map<String, IStory> get() = _registeredStories.toMap()
    val registeredWarps: Map<String, IWarp> get() = _registeredWarps.toMap()

    // ── 구현체 등록 (core 모드가 호출) ──

    fun registerTrait(trait: ITrait) {
        check(!_registeredTraits.containsKey(trait.id)) { "Trait already registered: ${trait.id}" }
        _registeredTraits[trait.id] = trait
    }

    fun registerSkill(skill: ISkill) {
        check(!_registeredSkills.containsKey(skill.id)) { "Skill already registered: ${skill.id}" }
        _registeredSkills[skill.id] = skill
    }

    fun registerStory(story: IStory) {
        check(!_registeredStories.containsKey(story.id)) { "Story already registered: ${story.id}" }
        _registeredStories[story.id] = story
    }

    fun registerWarp(warp: IWarp) {
        check(!_registeredWarps.containsKey(warp.id)) { "Warp already registered: ${warp.id}" }
        _registeredWarps[warp.id] = warp
    }

    // ── 조회 (ui 모드가 호출) ──

    fun getTrait(id: String): ITrait? = _registeredTraits[id]
    fun getSkill(id: String): ISkill? = _registeredSkills[id]
    fun getStory(id: String): IStory? = _registeredStories[id]
    fun getWarp(id: String): IWarp? = _registeredWarps[id]

    // ── 플레이어 데이터 ──

    fun getPlayerData(): IPlayerData? = _playerDataProvider?.invoke()

    private var _playerDataProvider: (() -> IPlayerData)? = null

    /**
     * core 모드가 플레이어 데이터 조회 콜백을 등록한다.
     */
    fun setPlayerDataProvider(provider: () -> IPlayerData) {
        _playerDataProvider = provider
    }

    // ── 데이터 동기화 이벤트 (pure listener pattern) ──

    private val _syncListeners = mutableListOf<(data: IPlayerData, fullSync: Boolean) -> Unit>()

    /**
     * ui 모드가 데이터 변경 알림을 구독한다.
     */
    fun onSync(listener: (data: IPlayerData, fullSync: Boolean) -> Unit) {
        _syncListeners.add(listener)
    }

    /**
     * core 모드가 데이터 변경을 알린다.
     */
    fun notifySync(fullSync: Boolean = false) {
        val data = getPlayerData() ?: return
        _syncListeners.forEach { it(data, fullSync) }
    }
}
